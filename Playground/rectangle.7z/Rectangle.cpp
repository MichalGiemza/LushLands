#include "Rectangle.h"

Rectangle::Rectangle(int x, int z, int w, int l, bool accurate) {
	p = new Position(x, 0, z, accurate);
	s = new Size(w, 0, l, accurate);
}

int Rectangle::accurateLeft() const {
	return p->getAccurateX();
}

int Rectangle::accurateRight() const {
	return p->getAccurateX() + s->getAccurateWidth();
}

int Rectangle::accurateTop() const {
	return p->getAccurateZ();
}

int Rectangle::accurateBottom() const {
	return p->getAccurateZ() + s->getAccurateLength();
}

int Rectangle::left() const {
	return p->x();
}

int Rectangle::right() const {
	return p->x() + s->w();
}

int Rectangle::top() const {
	return p->z();
}

int Rectangle::bottom() const {
	return p->z() + s->l();
}

void Rectangle::setPosition(Position *newPosition) {
	p = newPosition;
}

void Rectangle::setSize(Size *newSize) {
	s = newSize;
}

Position *Rectangle::getPosition() {
	return p;
}

Size *Rectangle::getSize() {
	return s;
}

bool Rectangle::isOverlapping(const Rectangle *other) const {
	// Determine left-right and top-bottom pairs
	const Rectangle *lRect = p->getAccurateX() < other->p->getAccurateX() ? this : other;
	const Rectangle *rRect = p->getAccurateX() >= other->p->getAccurateX() ? this : other;
	const Rectangle *bRect = p->getAccurateY() < other->p->getAccurateY() ? this : other;
	const Rectangle *tRect = p->getAccurateY() >= other->p->getAccurateY() ? this : other;

	bool x_overlapping = lRect->accurateRight() > rRect->accurateLeft();
	bool y_overlapping = bRect->accurateTop() > tRect->accurateBottom();

	return x_overlapping and y_overlapping;
}
